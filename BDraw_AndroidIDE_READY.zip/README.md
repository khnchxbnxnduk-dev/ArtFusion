# BDraw — Drawing Edition V5

รุ่นนี้ตัดระบบ Animation ออกก่อน และโฟกัสแกนแอปวาดภาพ

## ฟังก์ชันที่ทำงานจริงในรุ่นนี้
- Brush / Eraser / Line / Rectangle / Ellipse
- Stabilizer, opacity, size และ brush presets
- Flood Fill จริง
- Eyedropper
- Lasso selection เบื้องต้น
- Transform เบื้องต้น
- Text
- Gradient
- Grid / Ruler / Symmetry
- Layer: เพิ่ม/ลบ/ซ่อน, opacity, blend modes, alpha lock, clipping flags
- Undo / Redo history
- Import รูป
- Filters: invert, grayscale, brightness, darken, contrast, blur
- Export PNG/JPG/WebP
- UI ภาษาไทย
- ใช้ไอคอน BDraw เดิม

## เป้าหมายถัดไป
เพิ่มระบบ selection ขั้นสูง, mesh/perspective transform, mask, adjustment layer, manga panel/screentone/speech bubble, material/reference browser, advanced brush engine, color management และเครื่องมือฟิลเตอร์เพิ่มเติมให้ครอบคลุม workflow แบบ ibisPaint มากขึ้น

Animation จะไม่รวมใน V5 และจะทำเป็นอัปเดตภายหลัง
