# ArtFusion V1
Android prototype for a unified drawing + animation + future 3D app.

Current prototype:
- pressure-independent freehand brush canvas
- undo / clear
- onion-skin style ghost preview
- timeline/tool bar UI
- foundation for layers and frame system

Build with Android Studio and Gradle.
