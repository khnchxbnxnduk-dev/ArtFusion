# BDraw — รายการฟังก์ชันเป้าหมาย

## เครื่องมือหลัก
- [x] Brush / Eraser
- [x] Line / Rectangle / Oval
- [x] Eyedropper
- [x] Lasso (พื้นฐาน)
- [x] Transform (พื้นฐาน)
- [x] Fill (พื้นฐาน)
- [x] Stabilizer
- [x] Ruler / Perspective guides
- [x] Symmetry
- [x] Text (พื้นฐาน)
- [x] Gradient tool (พื้นฐาน)

## Selection / Transform ที่ต้องทำให้สมบูรณ์
- [ ] Magic Wand
- [ ] Selection Layer
- [ ] Rectangle / Ellipse selection
- [ ] Cut / Copy / Paste
- [ ] Invert / Expand / Contract / Feather
- [ ] Translate / Scale / Rotate
- [ ] Perspective transform
- [ ] Mesh transform
- [ ] Repeat transform

## Layer
- [x] Opacity
- [x] Blend-mode controls
- [x] Clipping / Alpha Lock controls
- [ ] Layer folders
- [ ] Masks
- [ ] Adjustment layers
- [ ] Layer ordering by drag
- [ ] Layer import from photo

## Brush Engine
- [x] Basic presets
- [x] Size / opacity
- [x] Stabilizer
- [ ] Pressure curves
- [ ] Start/end taper
- [ ] Spacing
- [ ] Texture
- [ ] Scatter
- [ ] Rotation
- [ ] Brush lock
- [ ] Full preset library

## Color / Filter
- [ ] Hue / Saturation / Brightness
- [ ] Contrast
- [ ] Levels
- [ ] Tone Curve
- [ ] Gradation Map
- [ ] Blur / Sharpen
- [ ] Pixelate
- [ ] Waterdrop
- [ ] Fisheye / Sphere
- [ ] Ripple / Wave / Swirl
- [ ] Polar Coordinates
- [ ] Glitch / Channel Shift
- [ ] Outline / Drop Shadow
- [ ] Manga Background / Anime Background
- [ ] Advanced style filters

## Manga / Illustration
- [ ] Frame Divider
- [ ] Speech bubbles
- [ ] Screen tones
- [ ] Manga panels
- [ ] Perspective / Array rulers
- [ ] Reference window
- [ ] Materials browser
- [ ] Import images
- [ ] Canvas/DPI presets

## Text
- [x] Basic text
- [ ] Font picker
- [ ] Outline / shadow
- [ ] Text transform
- [ ] Large font library

## Project / Export
- [ ] Autosave
- [ ] Project file format
- [ ] Import/export project
- [x] PNG
- [x] PNG sequence
- [ ] JPG/WebP
- [ ] GIF encoder
- [ ] MP4 encoder
- [ ] Drawing-process video

## Animation integration
- [x] Timeline
- [x] Frame add/duplicate/delete
- [x] Onion skin
- [x] Playback
- [ ] Audio tracks
- [ ] Audio trimming/slicing
- [ ] MP4/GIF animation export

> เป้าหมายคือความสามารถใกล้เคียงชุดเครื่องมือของ ibisPaint โดยเขียนระบบของ BDraw เอง
> ไม่ใช่การคัดลอก source code, assets หรือ branding ของ ibisPaint.
