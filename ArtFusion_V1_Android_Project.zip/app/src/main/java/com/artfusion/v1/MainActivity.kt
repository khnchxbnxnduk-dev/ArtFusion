package com.artfusion.v1

import android.app.*
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import kotlin.math.max

class DrawView(context: android.content.Context): View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 8f }
    private val paths = mutableListOf<Path>()
    private var current: Path? = null
    private var opacity = 1f
    var onion = true
    override fun onDraw(c: Canvas) {
        c.drawColor(Color.rgb(245,245,248))
        if (onion && paths.isNotEmpty()) {
            val ghost = Paint(paint).apply { color = Color.argb((45*opacity).toInt(), 40,130,255); strokeWidth=6f }
            for (p in paths) { c.save(); c.translate(12f, 0f); c.drawPath(p, ghost); c.restore() }
        }
        for (p in paths) c.drawPath(p, paint)
        current?.let { c.drawPath(it, paint) }
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { current=Path(); current!!.moveTo(e.x,e.y); invalidate(); return true }
            MotionEvent.ACTION_MOVE -> { current?.lineTo(e.x,e.y); invalidate(); return true }
            MotionEvent.ACTION_UP -> { current?.let { paths.add(it) }; current=null; invalidate(); return true }
        }; return true
    }
    fun undo(){ if(paths.isNotEmpty()){paths.removeAt(paths.lastIndex);invalidate()} }
    fun clear(){paths.clear();invalidate()}
    fun setSize(v:Float){paint.strokeWidth=v}
}

class MainActivity: Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(28,29,34))}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        fun btn(t:String)=Button(this).apply{text=t;setTextColor(Color.WHITE);background=ColorDrawable(Color.rgb(50,52,60))}
        val title=TextView(this).apply{text="  ArtFusion  •  DRAW / ANIMATION / 3D";setTextColor(Color.WHITE);textSize=17f}
        top.addView(title,LinearLayout.LayoutParams(0,58,1f))
        val undo=btn("↶"); val clear=btn("Clear"); val onion=btn("Onion ✓")
        top.addView(undo);top.addView(onion);top.addView(clear)
        root.addView(top)
        val draw=DrawView(this)
        root.addView(draw,LinearLayout.LayoutParams(-1,0,1f))
        val bottom=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val timeline=TextView(this).apply{text="  TIMELINE   |   ◀  Frame 1   ▶   |   Onion Skin";setTextColor(Color.LTGRAY);textSize=15f;setPadding(10,12,10,12)}
        bottom.addView(timeline)
        val tools=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        listOf("Brush","Eraser","Layers","Frame +","Play","3D (soon)").forEach{tools.addView(btn(it),LinearLayout.LayoutParams(0,54,1f))}
        bottom.addView(tools)
        root.addView(bottom)
        setContentView(root)
        undo.setOnClickListener{draw.undo()}
        clear.setOnClickListener{draw.clear()}
        onion.setOnClickListener{draw.onion=!draw.onion;onion.text=if(draw.onion)"Onion ✓" else "Onion"}
    }
}