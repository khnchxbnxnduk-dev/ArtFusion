package com.artfusion.v1

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.InputStream
import kotlin.math.*

private enum class Tool { BRUSH, ERASER, LINE, RECT, OVAL, FILL, EYEDROPPER, LASSO, TRANSFORM, TEXT, GRADIENT, PAN }

private data class Layer(var name:String, var bitmap:Bitmap, var visible:Boolean=true, var opacity:Int=100, var blend:PorterDuff.Mode=PorterDuff.Mode.SRC_OVER, var alphaLock:Boolean=false, var clipping:Boolean=false)
private data class Snapshot(val layers:List<Layer>, val active:Int)

private fun cloneBitmap(src:Bitmap):Bitmap = src.copy(Bitmap.Config.ARGB_8888,true)
private fun cloneLayer(l:Layer)=Layer(l.name,cloneBitmap(l.bitmap),l.visible,l.opacity,l.blend,l.alphaLock,l.clipping)

private class DrawView(ctx:Context):View(ctx){
    var layers=mutableListOf<Layer>(); var active=0
    var tool=Tool.BRUSH; var color=Color.BLACK; var size=12f; var opacity=1f
    var stabilizer=true; var symmetry=false; var grid=false; var ruler=false
    var zoom=1f; var panX=0f; var panY=0f
    var undo:()->Unit={}; var commit:()->Unit={}
    private var path=Path(); private var downX=0f; private var downY=0f; private var lastX=0f; private var lastY=0f
    private var selecting=false; private var selection=Path(); private var selectionBounds:RectF?=null
    private var transformStart:PointF?=null; private var transformRect:RectF?=null

    override fun onDraw(c:Canvas){
        c.drawColor(Color.rgb(232,232,238)); c.save(); c.translate(width/2f+panX,height/2f+panY); c.scale(zoom,zoom)
        val bg=Paint().apply{color=Color.WHITE}; c.drawRect(-1200f,-800f,1200f,800f,bg)
        if(grid) drawGrid(c)
        layers.forEach { l -> if(l.visible){ val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{alpha=(l.opacity*255/100)}; c.drawBitmap(l.bitmap,-l.bitmap.width/2f,-l.bitmap.height/2f,p) } }
        if(path.isEmpty.not() && tool in setOf(Tool.BRUSH,Tool.ERASER,Tool.LINE,Tool.RECT,Tool.OVAL,Tool.GRADIENT)) drawStrokePreview(c)
        selectionBounds?.let{ r -> Paint(Paint.ANTI_ALIAS_FLAG).also{p->p.style=Paint.Style.STROKE;p.color=Color.rgb(30,110,220);p.pathEffect=DashPathEffect(floatArrayOf(14f,8f),0f);c.drawRect(r,p)} }
        c.restore()
    }
    private fun drawGrid(c:Canvas){val p=Paint().apply{color=Color.argb(45,80,80,80);strokeWidth=1f};for(x in -1200..1200 step 50)c.drawLine(x.toFloat(),-800f,x.toFloat(),800f,p);for(y in -800..800 step 50)c.drawLine(-1200f,y.toFloat(),1200f,y.toFloat(),p);if(ruler){p.color=Color.argb(100,255,160,0);p.strokeWidth=2f;c.drawLine(-1200f,0f,1200f,0f,p);c.drawLine(0f,-800f,0f,800f,p)}}
    private fun drawStrokePreview(c:Canvas){val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=color;alpha=(opacity*255).toInt();style=Paint.Style.STROKE;strokeWidth=size;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND;if(tool==Tool.ERASER)xfermode=PorterDuffXfermode(PorterDuff.Mode.CLEAR)};c.drawPath(path,p);if(symmetry&&tool!=Tool.ERASER){val q=Path(path);val m=Matrix().apply{setScale(-1f,1f)};q.transform(m);c.drawPath(q,p)}}
    private fun sx(x:Float)=(x-width/2f-panX)/zoom
    private fun sy(y:Float)=(y-height/2f-panY)/zoom
    private fun paintFor(eraser:Boolean=false)=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=color;alpha=(opacity*255).toInt();style=Paint.Style.STROKE;strokeWidth=size;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND;if(eraser)xfermode=PorterDuffXfermode(PorterDuff.Mode.CLEAR)}
    private fun activeBitmap()=layers[active].bitmap
    override fun onTouchEvent(e:MotionEvent):Boolean{
        val x=sx(e.x);val y=sy(e.y)
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN->{downX=x;downY=y;lastX=x;lastY=y;transformStart=PointF(x,y); path=Path(); path.moveTo(x,y); if(tool==Tool.LASSO){selecting=true;selection=Path();selection.moveTo(x,y)}; if(tool==Tool.TRANSFORM){transformRect=RectF(x,y,x,y)}; if(tool==Tool.PAN)return true
                if(tool==Tool.FILL){commit();floodFill(activeBitmap(),x,y,color);invalidate();return true}
                if(tool==Tool.EYEDROPPER){color=sample(x,y);invalidate();return true}
                if(tool==Tool.TEXT){commit();addText(x,y);return true};return true}
            MotionEvent.ACTION_MOVE->{
                if(tool==Tool.PAN){panX+=e.x-lastX;panY+=e.y-lastY;lastX=e.x;lastY=e.y;invalidate();return true}
                if(tool==Tool.BRUSH||tool==Tool.ERASER){val nx=if(stabilizer)(lastX*0.25f+x*0.75f)else x;val ny=if(stabilizer)(lastY*0.25f+y*0.75f)else y;path.quadTo(lastX,lastY,nx,ny);lastX=nx;lastY=ny}
                else if(tool==Tool.LASSO){selection.lineTo(x,y)}
                else if(tool==Tool.TRANSFORM){transformRect?.set(min(downX,x),min(downY,y),max(downX,x),max(downY,y))}
                else {path=shapePath(downX,downY,x,y)};invalidate();return true}
            MotionEvent.ACTION_UP->{
                if(tool==Tool.PAN)return true
                if(tool==Tool.LASSO){selection.close();selectionBounds=RectF().also{selection.computeBounds(it,true)};selecting=false;invalidate();return true}
                if(tool==Tool.TRANSFORM){applyTransform();return true}
                if(tool==Tool.BRUSH||tool==Tool.ERASER||tool==Tool.LINE||tool==Tool.RECT||tool==Tool.OVAL){commit();drawPathToLayer(path,tool==Tool.ERASER)}
                else if(tool==Tool.GRADIENT){commit();drawGradient(downX,downY,x,y)}
                path.reset();invalidate();return true}
        };return true
    }
    private fun shapePath(x1:Float,y1:Float,x2:Float,y2:Float)=Path().apply{when(tool){Tool.LINE->{moveTo(x1,y1);lineTo(x2,y2)};Tool.RECT->addRect(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2),Path.Direction.CW);Tool.OVAL->addOval(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2),Path.Direction.CW);else->{moveTo(x1,y1);lineTo(x2,y2)}}}
    private fun drawPathToLayer(pth:Path,eraser:Boolean){val c=Canvas(activeBitmap());c.drawPath(pth,paintFor(eraser));if(symmetry&&!eraser){val q=Path(pth);q.transform(Matrix().apply{setScale(-1f,1f)});c.drawPath(q,paintFor(false))}}
    private fun drawGradient(x1:Float,y1:Float,x2:Float,y2:Float){val b=activeBitmap();val p=Paint(Paint.ANTI_ALIAS_FLAG);p.shader=LinearGradient(x1,y1,x2,y2,color,Color.TRANSPARENT,Shader.TileMode.CLAMP);Canvas(b).drawRect(-b.width/2f,-b.height/2f,b.width/2f,b.height/2f,p)}
    private fun sample(x:Float,y:Float):Int{val b=activeBitmap();val px=(x+b.width/2).roundToInt().coerceIn(0,b.width-1);val py=(y+b.height/2).roundToInt().coerceIn(0,b.height-1);return b.getPixel(px,py)}
    private fun floodFill(b:Bitmap,x:Float,y:Float,newColor:Int){val sx=(x+b.width/2).roundToInt().coerceIn(0,b.width-1);val sy=(y+b.height/2).roundToInt().coerceIn(0,b.height-1);val old=b.getPixel(sx,sy);if(old==newColor)return;val q=java.util.ArrayDeque<Int>();q.add(sy*b.width+sx);val seen=BooleanArray(b.width*b.height);while(q.isNotEmpty()){val n=q.removeFirst();if(seen[n])continue;seen[n]=true;val px=n%b.width;val py=n/b.width;if(abs(b.getPixel(px,py)-old)>0)continue;b.setPixel(px,py,newColor);if(px>0)q.add(n-1);if(px<b.width-1)q.add(n+1);if(py>0)q.add(n-b.width);if(py<b.height-1)q.add(n+b.width)}}
    private fun addText(x:Float,y:Float){val d=AlertDialog.Builder(context);val input=EditText(context).apply{hint="ข้อความ"};d.setTitle("เพิ่มข้อความ").setView(input).setPositiveButton("เพิ่ม"){_,_->val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=color;textSize=48f;typeface=Typeface.DEFAULT};Canvas(activeBitmap()).drawText(input.text.toString(),x+activeBitmap().width/2f,y+activeBitmap().height/2f,p);invalidate()}.setNegativeButton("ยกเลิก",null).show()}
    private fun applyTransform(){val r=transformRect?:return;if(r.width()<2||r.height()<2)return;commit();val b=activeBitmap();val l=max(1,r.left.roundToInt()+b.width/2);val t=max(1,r.top.roundToInt()+b.height/2);val rr=min(b.width-1,r.right.roundToInt()+b.width/2);val bb=min(b.height-1,r.bottom.roundToInt()+b.height/2);if(rr<=l||bb<=t)return;val crop=Bitmap.createBitmap(b,l,t,rr-l,bb-t);val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);val c=Canvas(out);c.drawBitmap(b,0f,0f,null);val dst=RectF(r);c.drawBitmap(crop,null,dst,null);layers[active].bitmap=out;transformRect=null;selectionBounds=null;invalidate()}
    fun clearSelection(){selectionBounds=null;invalidate()}
}

class MainActivity:Activity(){
    private lateinit var view:DrawView; private val W=1200; private val H=800
    private var history=ArrayDeque<Snapshot>();private var redo=ArrayDeque<Snapshot>()
    private val yellow=Color.rgb(255,210,55)
    override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=yellow;window.navigationBarColor=Color.WHITE;view=DrawView(this);view.layers.add(Layer("พื้นหลัง",Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888)));view.active=0;view.commit={saveHistory()};setContentView(buildUI())}
    private fun saveHistory(){history.addLast(Snapshot(view.layers.map{cloneLayer(it)},view.active));if(history.size>30)history.removeFirst();redo.clear()}
    private fun undo(){if(history.isEmpty())return;redo.addLast(Snapshot(view.layers.map{cloneLayer(it)},view.active));val s=history.removeLast();view.layers=s.layers.map{cloneLayer(it)}.toMutableList();view.active=s.active.coerceIn(0,view.layers.lastIndex);view.invalidate();refreshLayers()}
    private fun redo(){if(redo.isEmpty())return;history.addLast(Snapshot(view.layers.map{cloneLayer(it)},view.active));val s=redo.removeLast();view.layers=s.layers.map{cloneLayer(it)}.toMutableList();view.active=s.active;view.invalidate();refreshLayers()}
    private fun buildUI():View{val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(248,248,250))};root.addView(top(),LinearLayout.LayoutParams(-1,58));val mid=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};mid.addView(toolPanel(),LinearLayout.LayoutParams(90,-1));mid.addView(view,LinearLayout.LayoutParams(0,0,1f));mid.addView(layerPanel(),LinearLayout.LayoutParams(210,-1));root.addView(mid,LinearLayout.LayoutParams(-1,0,1f));root.addView(bottom(),LinearLayout.LayoutParams(-1,64));return root}
    private fun top():View{val r=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(Color.WHITE)};r.addView(TextView(this).apply{text="BDraw";textSize=22f;setTypeface(typeface,Typeface.BOLD);setPadding(10,0,18,0)});r.addView(TextView(this).apply{text="วาดภาพ";textSize=14f;setTextColor(Color.DKGRAY)},LinearLayout.LayoutParams(0,-1,1f));r.addView(btn("↶",52){undo()});r.addView(btn("↷",52){redo()});r.addView(btn("เปิดรูป",82){pickImage()});r.addView(btn("ส่งออก",82){exportDialog()});return r}
    private fun toolPanel():View{val s=ScrollView(this);val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};fun t(label:String,t:Tool)=c.addView(btn(label,54){view.tool=t});t("แปรง",Tool.BRUSH);t("ยางลบ",Tool.ERASER);t("เส้น",Tool.LINE);t("สี่เหลี่ยม",Tool.RECT);t("วงกลม",Tool.OVAL);t("เทสี",Tool.FILL);t("ดูดสี",Tool.EYEDROPPER);t("Lasso",Tool.LASSO);t("แปลง",Tool.TRANSFORM);t("ข้อความ",Tool.TEXT);t("ไล่สี",Tool.GRADIENT);t("เลื่อน",Tool.PAN);c.addView(btn("ฟิลเตอร์",54){filterDialog()});c.addView(btn("Ruler",54){view.ruler=!view.ruler;view.grid=true;view.invalidate()});c.addView(btn("สมมาตร",54){view.symmetry=!view.symmetry;view.invalidate()});c.addView(btn("Grid",54){view.grid=!view.grid;view.invalidate()});s.addView(c);return s}
    private fun layerPanel():View{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)};box.addView(TextView(this).apply{text="เลเยอร์";textSize=18f;setTypeface(typeface,Typeface.BOLD);setPadding(8,8,8,5)});box.addView(btn("＋ เพิ่มเลเยอร์",48){view.commit();view.layers.add(0,Layer("เลเยอร์ ${view.layers.size+1}",Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888)));view.active=0;refreshLayers()});val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;tag="layerlist"};view.layers.forEachIndexed{i,l->list.addView(btn((if(i==view.active)"● " else "○ ")+l.name,46){view.active=i;refreshLayers()})};scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));box.addView(btn("ตั้งค่าเลเยอร์",48){layerSettings()});box.addView(btn("ลบเลเยอร์",48){if(view.layers.size>1){view.commit();view.layers.removeAt(view.active);view.active=0;refreshLayers()}});return box}
    private fun refreshLayers(){setContentView(buildUI())}
    private fun bottom():View{val r=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(Color.WHITE)};r.addView(btn("สี",60){colorDialog()});r.addView(btn("ขนาด",70){seek("ขนาด",1,100,view.size.toInt()){view.size=it.toFloat()}});r.addView(btn("ทึบ",70){seek("ความทึบ",1,100,(view.opacity*100).toInt()){view.opacity=it/100f}});r.addView(btn("กันสั่น",80){view.stabilizer=!view.stabilizer});r.addView(btn("Brush",75){brushDialog()});r.addView(btn("เลือกทั้งหมด",90){view.selectionBounds=RectF(-W/2f,-H/2f,W/2f,H/2f);view.invalidate()});r.addView(btn("ล้างเลือก",75){view.clearSelection()});return r}
    private fun btn(s:String,w:Int,a:()->Unit)=Button(this).apply{text=s;textSize=11f;setTextColor(Color.rgb(35,35,42));background=ColorDrawable(yellow);setPadding(2,0,2,0);layoutParams=LinearLayout.LayoutParams(w,-1).apply{setMargins(2,2,2,2)};setOnClickListener{a()}}
    private fun colorDialog(){val colors=listOf(Color.BLACK,Color.WHITE,Color.RED,Color.BLUE,Color.GREEN,Color.YELLOW,Color.MAGENTA,Color.CYAN,Color.rgb(255,128,0),Color.rgb(130,80,40),Color.rgb(120,80,180),Color.rgb(40,150,130));val g=GridLayout(this).apply{columnCount=4};colors.forEach{cc->g.addView(Button(this).apply{background=ColorDrawable(cc);setOnClickListener{view.color=cc}},GridLayout.LayoutParams().apply{width=90;height=60;setMargins(3,3,3,3)})};AlertDialog.Builder(this).setTitle("สี").setView(g).setNegativeButton("ปิด",null).show()}
    private fun seek(title:String,min:Int,max:Int,value:Int,done:(Int)->Unit){val s=SeekBar(this).apply{this.max=max-min;progress=(value-min).coerceIn(0,this.max)};AlertDialog.Builder(this).setTitle(title).setView(s).setPositiveButton("ตกลง"){_,_->done(s.progress+min);view.invalidate()}.setNegativeButton("ยกเลิก",null).show()}
    private fun brushDialog(){val names=arrayOf("ปากกากลม","ดินสอ","หมึก","Airbrush","Marker","เส้นนุ่ม");AlertDialog.Builder(this).setTitle("Brush Presets").setItems(names){_,i->view.size=when(i){1->5f;2->9f;3->30f;4->18f;5->14f;else->12f};view.invalidate()}.show()}
    private fun layerSettings(){val l=view.layers[view.active];val items=arrayOf("Opacity","Alpha Lock","Clipping","Multiply","Screen","Add","Normal","ซ่อน/แสดง");AlertDialog.Builder(this).setTitle(l.name).setItems(items){_,i->when(i){0->seek("Opacity",0,100,l.opacity){l.opacity=it};1->{l.alphaLock=!l.alphaLock};2->{l.clipping=!l.clipping};3->{l.blend=PorterDuff.Mode.MULTIPLY};4->{l.blend=PorterDuff.Mode.SCREEN};5->{l.blend=PorterDuff.Mode.ADD};6->{l.blend=PorterDuff.Mode.SRC_OVER};7->{l.visible=!l.visible}};view.invalidate()}.show()}
    private fun filterDialog(){val names=arrayOf("กลับสี","ขาวดำ","สว่างขึ้น","มืดลง","คอนทราสต์ +","เบลอ");AlertDialog.Builder(this).setTitle("ฟิลเตอร์").setItems(names){_,i->view.commit();val b=view.layers[view.active].bitmap;val c=Canvas(b);when(i){0->{val cm=ColorMatrix(floatArrayOf(-1f,0f,0f,0f,255f,0f,-1f,0f,0f,255f,0f,0f,-1f,0f,255f,0f,0f,0f,1f,0f));c.drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)})};1->{val cm=ColorMatrix();cm.setSaturation(0f);c.drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)})};2->{val cm=ColorMatrix(floatArrayOf(1f,0f,0f,0f,25f,0f,1f,0f,0f,25f,0f,0f,1f,0f,25f,0f,0f,0f,1f,0f));c.drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)})};3->{val cm=ColorMatrix(floatArrayOf(1f,0f,0f,0f,-25f,0f,1f,0f,0f,-25f,0f,0f,1f,0f,-25f,0f,0f,0f,1f,0f));c.drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)})};4->{val s=1.25f;val t=-32f;val cm=ColorMatrix(floatArrayOf(s,0f,0f,0f,t,0f,s,0f,0f,t,0f,0f,s,0f,t,0f,0f,0f,1f,0f));c.drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)})};5->{val p=Paint(Paint.ANTI_ALIAS_FLAG);p.maskFilter=BlurMaskFilter(5f,BlurMaskFilter.Blur.NORMAL);c.drawBitmap(b,0f,0f,p)}};view.invalidate()}.show()}
    private fun pickImage(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},10)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK){val uri=d?.data?:return;contentResolver.openInputStream(uri)?.use{ins->val bm=BitmapFactory.decodeStream(ins)?:return;view.commit();val b=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas(b).drawBitmap(bm,null,Rect(0,0,W,H),null);view.layers.add(0,Layer("รูปนำเข้า",b));view.active=0;refreshLayers()}}}
    private fun exportDialog(){val names=arrayOf("PNG โปร่งใส","JPG","WebP");AlertDialog.Builder(this).setTitle("ส่งออกภาพ").setItems(names){_,i->export(i)}.show()}
    private fun composite():Bitmap{val out=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);val c=Canvas(out);view.layers.asReversed().forEach{l->if(l.visible){val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{alpha=l.opacity*255/100;xfermode=PorterDuffXfermode(l.blend)};c.drawBitmap(l.bitmap,-W/2f,-H/2f,p)}};return out}
    private fun export(kind:Int){val b=composite();val ext=when(kind){0->"png";1->"jpg";else->"webp"};val mime=when(kind){0->"image/png";1->"image/jpeg";else->"image/webp"};val name="BDraw_${System.currentTimeMillis()}.$ext";val v=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,mime);put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/BDraw")};contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?.let{contentResolver.openOutputStream(it)?.use{os->b.compress(when(kind){0->Bitmap.CompressFormat.PNG;1->Bitmap.CompressFormat.JPEG;else->Bitmap.CompressFormat.WEBP_LOSSY},95,os)}};Toast.makeText(this,"ส่งออก $ext แล้ว",Toast.LENGTH_SHORT).show()}
}
