# BDraw — AndroidIDE

โปรเจกต์นี้จัดโครงสร้างสำหรับเปิดเป็น Gradle Android project บน AndroidIDE/IDE ที่รองรับ Gradle

## เปิดบนมือถือ
1. แตกไฟล์ ZIP
2. เปิด AndroidIDE
3. เลือก Open/Import Project แล้วเลือกโฟลเดอร์ที่มี `settings.gradle` และ `build.gradle`
4. รอให้ Gradle sync เสร็จ
5. กด Build/Run เพื่อสร้าง APK

Gradle: 8.9
Android Gradle Plugin: 8.7.3
Kotlin: 2.0.21
JDK: 17
compileSdk/targetSdk: 35
